export default class Customer {
    id: string;
    username: string;
    password: string;
    address: string;
}
