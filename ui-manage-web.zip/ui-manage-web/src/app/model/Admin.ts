export default class Admin {
    id: string;
    username: string;
    password: string;
    adminRole: any;
}
