export default class Product {
    id: number;
    name: string;
    description: string;
    // tslint:disable-next-line: variable-name
    entry_price: number;
    price: number;
    total: number;
}
