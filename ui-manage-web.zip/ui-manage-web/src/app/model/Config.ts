export const BASE_URL = 'http://localhost:8080/api/';
export const FIND_ALL_PRODUCT = BASE_URL + 'get-all-products';
export const FIND_ALL_CUSTOMER = BASE_URL + 'get-all-customers';
export const FIND_ALL_ADMIN = BASE_URL + 'get-all-admins';
export const FIND_ALL_ORDER = BASE_URL + 'get-all-orders';
