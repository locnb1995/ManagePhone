export const SUCCESS = 'success';
export const ERROR = 'error';
