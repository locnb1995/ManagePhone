export default class TableResponse {
    status: string;
    data: Array<any>;
    message: string;
}
